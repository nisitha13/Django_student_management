from django.contrib import admin
from .models import JobApplication

admin.site.register(JobApplication)

