from django.shortcuts import render, redirect
from .forms import JobApplicationForm
from .models import JobApplication

def apply(request):
    if request.method == "POST":
        form = JobApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = JobApplicationForm()
    return render(request, 'apply.html', {'form': form})

def success(request):
    return render(request, 'success.html')

